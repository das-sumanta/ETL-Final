package com.tcs;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;

public final class Utility {
	private static Connection con;
	private static PreparedStatement ps;
	public static String logDbUid;
	public static String logDbPwd;
	public static String logDbURL;
	public static String logLocation;
	public static Logger logger = Logger.getLogger("AppLog");
	public static int runID;
	public static Map<String, Long> dbObjectJobIdMap = new HashMap<>();
	public static Map<String, String> encConfig = new HashMap<>();
	public static String dateFormat;
	private static String[] DIM;
	public static String SUBID; 
	public static String factExtConstDt;
	
	private Utility() {

	}

	public static void applicationStart(boolean isManual,String subsidiaryId) {

		Properties properties = new Properties();
		File pf = new File("config.properties");
		
		try {
			properties.load(new FileReader(pf));
			EncryptionUtil.cipher = Cipher.getInstance("AES");

			logDbURL = properties.getProperty("LogDBURL");
			logDbUid = properties.getProperty("LogDBUID");
			logDbPwd = properties.getProperty("LogDBPwd");
			dateFormat = properties.getProperty("DateFormat");
			DIM = properties.getProperty("Dimensions1").split(","); 
			SUBID = subsidiaryId;
			factExtConstDt =  properties.getProperty("FactExtConstDt");
			
			con = createConnection(logDbURL, logDbUid, logDbPwd);
			
						
			

		} catch (FileNotFoundException e) {
			System.out.println("FileNotFound exception" + e.getMessage());
			System.exit(0);
		} catch (IOException e) {
			System.out.println("IO exception" + e.getMessage());
			System.exit(0);
		} catch (NoSuchAlgorithmException e) {

			e.printStackTrace();
		} catch (NoSuchPaddingException e) {

			e.printStackTrace();
		}

	}


	
	public static Connection createConnection(String url, String uid, String pwd) {

		Connection conn = null;
		try {

			// Loading the driver
			Class.forName("com.mysql.jdbc.Driver");
			// Creating a connection

			logDbURL = url;
			logDbUid = uid;
			logDbPwd = pwd;
			conn = DriverManager.getConnection(logDbURL, logDbUid, logDbPwd);
			return conn;

		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found");
			
			System.exit(0);
		} catch (SQLException sq1ex) {

			System.out.println("Connection exception " + sq1ex.getMessage()); 
			System.exit(0);

		}

		return conn;
	}

	

	public void updateConfig(String property, String value) {

		PreparedStatement ps;
		String logSql = "";

		try {

			if (con.isClosed()) {
				con = createConnection(logDbURL, logDbUid, logDbPwd);
			}

			logSql = "UPDATE p2p_config SET value = ? WHERE key = ?";
			ps = con.prepareStatement(logSql);
			ps.setString(1, value);
			ps.setString(2, property);
			ps.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();

		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			closeConnection(con);
		}

	}

	public static String getConfig(String property) {

		String logSql = "";
		ResultSet rs = null;
		try {
			
			if(encConfig.containsKey(property)) {
				
				return EncryptionUtil.decrypt(encConfig.get(property),encConfig.get("SECRETKEY"));
			} else {
			
				if (con.isClosed()) {
					con = createConnection(logDbURL, logDbUid, logDbPwd);
				}
				logSql = "SELECT property, value FROM p2p_config";
				ps = con.prepareStatement(logSql);
				rs = ps.executeQuery();
				
				while(rs.next()) {
					encConfig.put(rs.getString(1), rs.getString(2));
				}
	
				return EncryptionUtil.decrypt(encConfig.get(property),encConfig.get("SECRETKEY"));
			}

		} catch (SQLException e) {

			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			closeConnection(con);
		}

		return "";
	}

	
	public static void closeConnection(Connection con) {

		try {
			
			if (!con.isClosed()) {
				if(!con.getAutoCommit())
					con.commit();
				con.close();
				con = null;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static String getCurrentDate() {
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		Date curDate = new Date();
		String strDate = sdf.format(curDate);
		return strDate;
	}
	
	

	public static String getDatesFromFact(String factName, String subId, String startDt, String endDt) throws SQLException{
		String logSql = "";
		String extTSStr = "";

		try {
			if (con.isClosed()) {
				con = createConnection(logDbURL, logDbUid, logDbPwd);
			}

			logSql = "SELECT ext_end_dt FROM data_ext_dtl where fact_name=? and subsidiary_id=?";

			ps = con.prepareStatement(logSql);
			ps.setString(1, factName);
			ps.setString(2, subId);

			ResultSet rs = ps.executeQuery();
			if (rs != null && rs.next()) {
				Timestamp extTs = rs.getTimestamp(1);
				
				extTSStr=extTs.toString().substring(0, extTs.toString().length()-2);
			} else {
				
				throw new SQLException("Table fact_ext_dtl is missing "+factName+" entry.");

			}

			
		} catch (SQLException e) {
			throw new SQLException(e.toString());

		} finally {

			closeConnection(con);
		}

		return extTSStr;
	}

	public static void updateFactExtDtl(String factName, String subId, String startDt, String endDt) throws SQLException{
		String logSql = "";
		try {
			if (con.isClosed()) {
				con = createConnection(logDbURL, logDbUid, logDbPwd);
			}

			logSql = "UPDATE data_ext_dtl SET ext_start_dt=STR_TO_DATE(?,'%Y-%m-%d %H:%i:%s') , ext_end_dt=STR_TO_DATE(?,'%Y-%m-%d %H:%i:%s') where fact_name=? and subsidiary_id=?";

			ps = con.prepareStatement(logSql);
			ps.setString(1, startDt);
			ps.setString(2, endDt);
			ps.setString(3, factName);
			ps.setString(4, subId);
			ps.executeUpdate();
			System.out.println("FactExtDtl updated.");

		} catch (SQLException e) {
			throw new SQLException(e.toString());

		} finally {

			closeConnection(con);
		}

	}
	
	
	
	public static void updateFactsProperty(String propName, String key, String value) throws FileNotFoundException {

		Properties props = new Properties();
		Writer writer = null;
		File f = new File(propName);
		if (f.exists()) {
			try {

				props.load(new FileReader(f));
				props.setProperty(key.trim(), value.trim());
				System.out.println("\nUpdated file "+propName+"\n");
				writer = new FileWriter(f);
				props.store(writer, null);
				writer.close();
			} catch (IOException e) {

				e.printStackTrace(); //TODO remove this
			}

		} else {
			throw new FileNotFoundException("Invalid Properties file or "+ propName + " not found");
		}
	}

}