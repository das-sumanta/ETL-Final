package com.tcs;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;

public class DataLoaderUtil {
	
	private String appConfigPropFile;
	private List<String> dimensions;
	private List<String> facts;
	private Connection con;
	private String connectionString;
	private Statement statement;
	private ResultSet resultSet;
	private String query;
	private String extractLocationLocal;
	private String extractLocationURL;
	private String extractLocationS3;
	private String sqlScript;
	private TransferManager tx;
	private Upload upload;
	private String awsProfile;
	private String redShiftMasterUsername;
	private String redShiftMasterUserPassword;
	private String redShiftPreStageSchemaName;
	private String dbURL;
	private Map<String, String> checkList = new HashMap<String, String>();
	private char csvDelimiter;
	private String[] extractURL;
	private  List<String> extractURLTableName;
	private Map<String, Long> insertIDList = new HashMap<String, Long>();
	private boolean isDWEntryRestricted;
	private String dateTimeFormat;
	private SimpleDateFormat sdf;
	private SimpleDateFormat sdfType1;
	
	
	public DataLoaderUtil() {
		
		
		try {
			appConfigPropFile = "config.properties";
			Properties properties = new Properties();
			File pf = new File(appConfigPropFile);
			properties.load(new FileReader(pf));
			
			extractLocationLocal = System.getProperty("user.dir") + File.separator
					+ "db_extracts" + File.separator +  Utility.getCurrentDate();
			extractLocationURL = System.getProperty("user.dir") + File.separator
					+ "url_db_extracts" + File.separator +  Utility.getCurrentDate();
			extractLocationS3 = properties.getProperty("s3bucket");
			sqlScript = properties.getProperty("FactFileLoc");
			
			awsProfile = Utility.getConfig("AWSPROFILE");
			redShiftMasterUsername = Utility.getConfig("RSUID");;
			redShiftMasterUserPassword = Utility.getConfig("RSPWD");
			redShiftPreStageSchemaName = properties.getProperty("RSSCHEMAPRESTAGE");
			dbURL = Utility.getConfig("RSDBURL");
			csvDelimiter = properties.getProperty("CSVDelim").charAt(0);
			extractURL = properties.getProperty("FileExtractURL").split(",");
			dateTimeFormat = properties.getProperty("DateTimeFormat");
			sdf = new SimpleDateFormat(dateTimeFormat);
			sdfType1 = new SimpleDateFormat(properties.getProperty("DateTimeFormatType1"));
			
			new File(extractLocationLocal).mkdirs();
			new File(extractLocationURL).mkdirs();
			
			Class.forName(Utility.getConfig("NETSUITEDRIVER"));

			connectionString = String
					.format("jdbc:ns://%s:%d;ServerDataSource=%s;encrypted=1;CustomProperties=(AccountID=%s;RoleID=%d)",
							Utility.getConfig("NETSUITESERVERHOST"), Integer.parseInt(Utility.getConfig("NETSUITEPORT")), Utility.getConfig("NETSUITEDATASOURCE"), Utility.getConfig("NETSUITEACCOUNTID"),
							Integer.parseInt(Utility.getConfig("NETSUITEROLEID")));

			con = DriverManager.getConnection(connectionString, Utility.getConfig("NETSUITELOGIN"), Utility.getConfig("NETSUITEPASSWORD"));

			System.out.println("************************************ WELCOME TO EDW CUSTOM ETL UTILITIES ************************************");
			
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		} 
	}
	
	public void createFactExtract() throws SQLException, IOException {

		Statement st = null;
		ResultSet rs = null;
		String lastModDate;
		String currDate = null;

		Properties tmpProp = new Properties();
		File tmpFile = new File("tmpFile.properties");
		tmpFile.createNewFile();

		try {
			tmpProp.load(new FileReader(tmpFile));

		} catch (IOException e) {

			throw new IOException(e.toString());
		}

		try {
			BufferedReader in = new BufferedReader(new FileReader(sqlScript));

			Scanner scn = new Scanner(in);
			scn.useDelimiter("/\\*[\\s\\S]*?\\*/|--[^\\r\\n]*|;");

			st = con.createStatement();

			while (scn.hasNext()) {
				String line = scn.next().trim();

				if (!line.isEmpty()) {
					
					lastModDate = Utility.getDatesFromFact("NS", Utility.SUBID, Utility.factExtConstDt, Utility.factExtConstDt);
					String[] queryParts= line.split("UNION");
					StringBuilder finalQuery= new StringBuilder();
					for(String queryPart:queryParts){
						finalQuery.append(String.format(queryPart, Utility.SUBID,lastModDate));
						finalQuery.append("UNION");
					}
					finalQuery.delete(finalQuery.lastIndexOf("UNION"),finalQuery.length());
					
					
					Calendar now = Calendar.getInstance();
					//System.out.println(sdf.format(now.getTime()));
					now.add(Calendar.HOUR, -5);
					now.add(Calendar.MINUTE,-30);
					//System.out.println(sdf.format(now.getTime()));
					currDate = sdf.format(now.getTime());
					
					rs = st.executeQuery(finalQuery.toString());
					
					
					
					//currDate = sdf.format(Calendar.getInstance().getTime());
					lastModDate =  Utility.SUBID + "," + lastModDate + "," + currDate;
					Utility.updateFactsProperty("tmpFile.properties", "NS",	lastModDate);
					
					if (rs.next()) {

						System.out.println("Retrieving data...");

						

						Date curDate = new Date();
						String strDate = sdfType1.format(curDate);

						String fileName = extractLocationLocal + File.separator
								+ "ns" + "-" + "-"
								+ strDate + ".csv";
						File file = new File(fileName);
						FileWriter fstream = new FileWriter(file);
						BufferedWriter out = new BufferedWriter(fstream);

						String str = "";
						List<String> columnNames = getColumnNames(rs);
						for (int c = 0; c < columnNames.size(); c++) {
							str = "\"" + columnNames.get(c) + "\"";
							out.append(str);
							if (c != columnNames.size() - 1) {
								out.append(csvDelimiter);
							}
						}
						
						ResultSet cs = st.executeQuery(finalQuery.toString());
						
						while (cs.next()) {
							List<Object> row = new ArrayList<Object>();
							row.add(Utility.runID);
							for (int k = 0; k <columnNames.size() - 1; k++) {
								row.add(cs.getObject(k + 1)); 
							}

							out.newLine();
							for (int j = 0; j < row.size(); j++) {
								if (!String.valueOf(row.get(j)).equals("null")) {
									String tmp = "\""
											+ String.valueOf(row.get(j)) + "\"";
									out.append(tmp);
									if (j != row.size() - 1) {
										out.append(csvDelimiter);
									}
								} else {
									if (j != row.size() - 1) {
										out.append(csvDelimiter);
									}
								}
							}
						}
						out.close();
						fstream.close();

						checkList.put("NS", "Extraction Done");
						System.out.println("Extraction Completed for NS");
						
						
					} else {
						
						//insertIDList.remove(factName);
						System.out.println("No resultset generated after executing query for NS where DATE_LAST_MODIFIED >= "
										+ lastModDate);
						
								
						checkList.put("NS", "Extraction Error");
						scn.close();

						if (st != null)
							st.close();
						return;

					}

				}

			}
			scn.close();
			if (st != null)
				st.close();

		} catch (FileNotFoundException e) {  //All commented as handled in calling method

		//	Utility.writeLog("RunID " + Utility.runID + " Error!!" + e.getMessage(), "Error", "", process, "DB"); 
			throw new FileNotFoundException(e.toString());

		} catch (SQLException e) {

		//	Utility.writeLog("RunID " + Utility.runID + " Error!!" + e.getMessage(), "Error", "", process, "DB");
			throw new SQLException(e.toString());

		} catch (IOException e) {

		//	Utility.writeLog("RunID " + Utility.runID + " Error!!" + e.getMessage(), "Error", "", process, "DB");
			throw new IOException(e.toString());

		} 

	}
	
	
	public void s3AndRedShiftUpload() throws IOException {
		AWSCredentials credentials = null;
		try {

			credentials = new ProfileCredentialsProvider(awsProfile).getCredentials();
		} catch (Exception e) {
			System.out.println("Error!!  Cannot load the credentials from the credential profiles file.");
			
			throw new AmazonClientException(
					"Cannot load the credentials from the credential profiles file. "
							+ "Please make sure that your credentials file is at the correct "
							+ "location, and is in valid format.", e);

		}

		AmazonS3 s3 = new AmazonS3Client(credentials);
		Region usWest2 = Region.getRegion(Regions.US_EAST_1);
		s3.setRegion(usWest2);
		tx = new TransferManager(s3);

		String bucketName = extractLocationS3;
		
		System.out.println("\n--------------------------------------------------------");
		System.out.println("Uploading DB Extracts to Amazon S3");
		System.out.println("--------------------------------------------------------");

		for (int i = 0; i < files.size(); i++) {
			
			if (!checkErrorStatus("Extraction", files.get(i))) {
								
				

				try {

					File s3File = getLastFileModifiedFile(extractLocationLocal,	files.get(i));
					Utility.writeLog("RunID " + Utility.runID + " Uploading " + s3File.getName()+ " to Amazon S3 bucket " + bucketName,	"Info", files.get(i), process, "DB");
					System.out.println("Uploading " + s3File.getName()+ " to S3...");

					PutObjectRequest request = new PutObjectRequest(bucketName,
							 Utility.getCurrentDate() + "/" + s3File.getName(), s3File);
					upload = tx.upload(request);
					upload.waitForCompletion();
					if(upload.getState().ordinal()==2)
					{

						Utility.writeJobLog(insertIDList.get(files.get(i)), "S3LOADEND", sdf.format(Calendar.getInstance().getTime()));

						Utility.writeLog("RunID " + Utility.runID +" "+ s3File.getName() + " transferred successfully.", "Info", files.get(i), process, "DB");

						System.out.println(files.get(i) + " file transferred.");

						Utility.writeJobLog(insertIDList.get(files.get(i)), "REDSHIFTLOADSTART", sdf.format(Calendar.getInstance().getTime()));

						if(proceedWithFactsLoad(files.get(i),i))
							loadDataToRedShiftDB(files.get(i), s3File.getName(), i);

					}

				} catch (AmazonServiceException ase) {

					Utility.writeLog("Caught an AmazonServiceException, which means your request made it "
									+ "to Amazon S3, but was rejected with an error response for some reason."
									+ " Error Message:" + ase.getMessage()
									+ " HTTP Status Code: "
									+ ase.getStatusCode() + " AWS Error Code: "
									+ ase.getErrorCode() + " Error Type: "
									+ ase.getErrorType() + " Request Id: "
									+ ase.getRequestId(), "Error", "", process, "DB");
					System.out.println("Caught an AmazonServiceException, which means your request made it "
									+ "to Amazon S3, but was rejected with an error response for some reason.");
					System.out.println("Error Message:    " + ase.getMessage());
					System.out.println("HTTP Status Code: "	+ ase.getStatusCode());
					System.out.println("AWS Error Code:   "	+ ase.getErrorCode());
					System.out.println("Error Type:       " + ase.getErrorType());
					System.out.println("Request ID:       "	+ ase.getRequestId());

					Utility.writeJobLog(insertIDList.get(files.get(i)), "Error","");

					checkList.put(files.get(i), "Loading Error");
					

				} catch (AmazonClientException ace) {
					checkList.put(files.get(i), "Loading Error");
					System.out.println("Error !! Please check error message "+ ace.getMessage());
					Utility.writeLog("Caught an AmazonClientException, which means the client encountered "
									+ "a serious internal problem while trying to communicate with S3, "
									+ "such as not being able to access the network."
									+ ace.getMessage(), "Error", files.get(i), process, "DB");
					Utility.writeJobLog(insertIDList.get(files.get(i)), "Error","");
					
				} catch (Exception e) {
					checkList.put(files.get(i), "Loading Error");
					System.out.println("Error !! Please check error message "+ e.getMessage());
					Utility.writeLog("RunID " + Utility.runID + " " + e.getMessage(), "Error", files.get(i), process, "DB");
					Utility.writeJobLog(insertIDList.get(files.get(i)), "Error","");
					
				} //Removed finally continue  Not required will continue

			} else {
				checkList.put(files.get(i), "Loading Error");  
				System.out.println("There is an issue while creating the extract of "+ files.get(i)	+ ". So loading operation is skipped for "+ files.get(i)+"\n");
				Utility.writeLog("As there is an issue while creating the extract of "+ files.get(i) + " so loading operation is skipped for "
						+ files.get(i), "Info", files.get(i), process, "DB");
				
				isDWEntryRestricted=true; 
				
			}
		}

		tx.shutdownNow();
	}
	
	public List<String> getColumnNames(ResultSet resultSet)
			throws SQLException {
		List<String> columnNames = new ArrayList<String>();
		ResultSetMetaData metaData = resultSet.getMetaData();
		columnNames.add("RunID");
		for (int i = 0; i < metaData.getColumnCount(); i++) {
			
			columnNames.add(metaData.getColumnName(i + 1));
		}
		return columnNames;
	}
	
	public boolean checkErrorStatus(String errorType, String tabName) {

		String status = checkList.get(tabName);
		
		boolean errorStatus = false;
		if(status != null ) {
			switch (errorType) {
			case "Extraction":
				if (status.equalsIgnoreCase("Extraction Error"))
					errorStatus = true;
				break;
	
			case "Loading":
				if (status.equalsIgnoreCase("Loading Error"))
					errorStatus = true;
				break;
			}
		}
		return errorStatus;

	}
		
	}


